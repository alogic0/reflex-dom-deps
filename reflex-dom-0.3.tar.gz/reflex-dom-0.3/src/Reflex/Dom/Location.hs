module Reflex.Dom.Location (getLocationHost, getLocationProtocol) where

import Reflex.Dom.Internal.Foreign
